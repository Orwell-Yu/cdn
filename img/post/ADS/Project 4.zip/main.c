#include<stdio.h>
#include<math.h>
#define MAXN 100005
#define MOD 1000000007

int m,n =0;
int num[MAXN]={0};

long long int dp[MAXN]={0};
//dp[i]表示以num[i]结尾的beautiful_subsequence的个数

int beautiful_subsequence(int num[]);//dp,返回值为beautiful_subsequence的个数
int my_pow(int n);//2^n,返回值为2^n%MOD

int main(){
    FILE *fp;
    fp=fopen("input100000.txt","r");
    fscanf(fp,"%d %d",&n,&m);
    for(int i=0;i<n;i++){
        fscanf(fp,"%d",&num[i]);
    }
    int ans=0;
    ans=beautiful_subsequence(num);
    printf("%d\n",ans);
}

int my_pow(int n){
    int x=1;
    while(n>0){
        x <<= 1;
        if (x>MOD) x%=MOD;
        n--;
    }
    return x;
}

int beautiful_subsequence(int num[]){
    for(int i=0;i<n;i++){
        for(int j=0;j<i;j++){
            if(abs(num[i]-num[j])<=m){
                dp[i]+=my_pow(j);
                if(dp[i]>MOD) dp[i]%=MOD;
            }
            else{
                dp[i]+=dp[j];
                if(dp[i]>MOD) dp[i]%=MOD;
            }
        }
    }
    int ans=0;
    for(int i=0;i<n;i++){
        ans+=dp[i];
        if(ans>MOD) ans=ans%MOD;
    }
    return ans;
}
/*
7 2
1 5 3 2 6 4 8
*/
/*
9 2
1 5 3 2 6 4 8 7 5
*/
/*
11 2
1 5 3 8 3 2 6 4 8 7 5
*/
/*
15 3
2 4 1 5 3 8 3 2 6 4 8 7 5 3 7
*/
/*
100 2
1 5 16 3 7 6 5 17 6 14 14 12 0 15 19 12 5 14 13 13 3 16 10 0 8 1 19 6 15 2 14 5 2 15 14 13 13 15 16 14 16 16 15 13 8 6 7 3 6 2 15 17 4 5 2 11 3 19 3 10 10 17 9 16 17 14 18 8 2 11 2 0 8 12 1 6 14 14 11 6 7 2 9 13 5 9 19 6 10 1 19 18 0 5 13 9 0 16 17 15
*/
/*
20 2
19 11 13 13 12 11 1 8 0 5 9 1 17 17 18 13 10 6 9 10
*/
/*
30 10
18 8 79 65 72 68 45 40 24 89 70 63 49 55 6 7 47 97 56 71 64 78 74 7 67 9 6 14 20 74
*/
/*
40 3
23 49 30 44 4 1 17 25 35 6 38 39 46 31 16 33 26 21 45 5 32 0 42 27 3 9 34 24 2 15 41 13 37 19 48 12 29 14 18 36
*/

