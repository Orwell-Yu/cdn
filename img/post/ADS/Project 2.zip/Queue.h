#pragma once
#include <stdlib.h>
#include <iostream>
#include "dijkstra.h"

using namespace std;


template <typename HEAP>
class Queue {
public:
	Queue() : min_heap() {};
	Queue(bool (*compare_func)(int, int)) : min_heap(compare_func){};

	int pop();
	void push_ele(int);
	bool empty();
private:
	HEAP min_heap;
};//end of class Queue

template<typename HEAP>
int Queue<HEAP>::pop()
{
	return min_heap.DeleteMin();
}

template<typename HEAP>
bool Queue<HEAP>::empty()
{
	return min_heap.empty();
}

template<typename HEAP>
void Queue<HEAP>::push_ele(int val)
{
	min_heap.push(val);
}

