#pragma once
#include "simple_comp.h"
class Node {
public:
	Node() :degree(0), left(this), right(this), child(nullptr), parent(nullptr),
		compare_func(simple_comp), val(-1) {};
	Node(int val) :degree(0), left(this), right(this), child(nullptr), parent(nullptr),
		compare_func(simple_comp), val(val) {};
	Node(int val, bool (*compare_func)(int, int)) :
		degree(0), left(this), right(this), child(nullptr), parent(nullptr),
		compare_func(compare_func), val(val) {};
	void set_parent(Node* p) { parent = p; };
	void set_child(Node* c) { child = c; }
	void set_left(Node* l) { left = l; }
	void set_right(Node* r) { right = r; }
	void set_degree(int d) { degree = d; };
	int get_val() { return val; }
	int get_degree() { return degree; }
	Node* get_child() { return child; }
	Node* get_right() { return right; }
	Node* get_left() { return left; }
	void Insert(Node*); //Insert a node into the root list

	//Reload the operator
	bool operator <= (Node n)
	{
		return compare_func(this->val, n.val);
	}
	bool operator > (Node n)
	{
		return !compare_func(this->val, n.val);
	}
	bool operator >= (Node n)
	{
		return compare_func(n.val, this->val);
	}
	bool operator < (Node n)
	{
		return !compare_func(n.val, this->val);
	}
private:
	int degree;//Number of children
	Node* left, * right, * child, * parent;
	int val;
	bool (*compare_func)(int, int);
};

class FHeap {
public:
	FHeap()
		:min_ptr(nullptr), compare_func(simple_comp), cur_size(0) {
		head = new Node();    //When initialize the heap, only one head node
		head->set_left(head);
		head->set_right(head);
	}
	FHeap(bool (*compare_func)(int, int))
		:min_ptr(nullptr), compare_func(compare_func), cur_size(0) {
		head = new Node();
		head->set_left(head);
		head->set_right(head);
	}
	~FHeap() { delete head; }
	bool empty() { return cur_size == 0; };
	bool size() { return cur_size; };
	void push(int val);
	int DeleteMin();
private:
	void Adjust();
	bool (*compare_func)(int, int);
	Node* head;
	Node* min_ptr;
	int cur_size;
};
