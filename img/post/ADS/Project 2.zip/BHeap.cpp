#include "BHeap.h"
#include <iostream>
using namespace std;

void BHeap::trans_BT(BinTree* bt, int pos)
{
	this->cur_size = (1 << pos) - 1;
	int P = pos - 1;
	for (BinTree* tmp_bt = bt->get_child(); tmp_bt; tmp_bt = tmp_bt->get_sib(), P--)
	{
		trees[P] = tmp_bt;   //Since sibling goes from large to small row, P decreases to 0
	}

	delete bt; //delete the root of the BinTree
}

int BHeap::DeleteMin()
{
	if (cur_size <= 0)
	{
		cout << "error in DeleteMin" << endl;
		exit(1);
	}
	int ret_val;

	//Find the BinTree where the smallest val is, obviously, so you don't know where the second smallest val is later, but Merge the two later
	//heap finds the next smallest val again, so min_pos after DeleteMin is still valid
	BinTree* bt = trees[min_pos];
	trees[min_pos] = nullptr;
	ret_val = bt->get_val();

	BHeap* tmp_h = new BHeap(compare_func);
	//tmp_h is used to store the BinTree that needs to be merged, and then merge it with the current heap
	//The reason for this is that the current heap may not have enough space to store the BinTree, so you need to create a new heap to store it

	tmp_h->trans_BT(bt, min_pos);
	this->cur_size -= tmp_h->cur_size + 1;   //size - 1
	Merge(tmp_h);

	delete tmp_h;
	return ret_val;
}

BinTree* merge(BinTree* bt1, BinTree* bt2)
{
	if (*bt1 > *bt2)
		return merge(bt2, bt1);

	bt2->set_sib(bt1->get_child());
	bt1->set_child(bt2);
	return bt1;
}

void BHeap::push(int val)
{
	BinTree* carry = new BinTree(val, compare_func);  //carry is the BinTree that needs to be merged
	BinTree* bt;

	if (cur_size == max_size) {
		max_size *= 2;
		BinTree** new_trees = new BinTree * [max_size];
		memcpy(new_trees, trees, cur_size * sizeof(BinTree*));
	}
	cur_size += 1;  //size + 1
	int min_val = (min_pos == -1 ? -1 : trees[min_pos]->get_val());
	//min_val is the smallest val in the current heap, if min_pos is -1, it means that the heap is empty, and the smallest val is -1

	for (int i = 0, j = 1; j <= cur_size; j <<= 1, i++)
	{
		bt = trees[i];
		if (bt) {
			carry = merge(bt, carry);   //merge the BinTree that needs to be merged with the BinTree in the current heap
			trees[i] = nullptr;
		}
		else
		{
			trees[i] = carry;

			//If the current heap is empty, or the val of the BinTree that needs to be merged is smaller than the smallest val in the current heap, update min_pos
			if (min_val < 0 || compare_func(trees[i]->get_val(), min_val))
				min_pos = i;
			break;
		}
	}
}

void BHeap::Merge(BHeap* h)
{
	cur_size += h->cur_size;
	BinTree* bt1, * bt2, * carry = nullptr;

	int temp_min_pos = -1, min_val;  //temp_min_pos is the position of the smallest val in the current heap, min_val is the smallest val in the current heap

	for (int i = 0, j = 1; j <= cur_size; j <<= 1, i++)
	{
		bt1 = this->trees[i];
		bt2 = h->trees[i];

		switch (!!carry * 4 + !!bt2 * 2 + !!bt1)  //carry bt1 bt2
		{
		case 0:
			break;//carry = nullptr, bt1 = nullptr, bt2 = nullptr
		case 1:
			break;//carry = nullptr, bt1 = nullptr, bt2 != nullptr
		case 2:
			this->trees[i] = bt2;
			h->trees[i] = nullptr;
			break;//carry = nullptr, bt1 != nullptr, bt2 = nullptr
		case 3:
			carry = merge(bt1, bt2);
			h->trees[i] = nullptr;
			this->trees[i] = nullptr;
			break;//carry = nullptr, bt1 != nullptr, bt2 != nullptr
		case 4:
			this->trees[i] = carry;
			carry = nullptr;
			break;//carry != nullptr, bt1 = nullptr, bt2 = nullptr
		case 5:
			carry = merge(carry, bt1);
			this->trees[i] = nullptr;
			break;//carry != nullptr, bt1 != nullptr, bt2 = nullptr
		case 6:
			carry = merge(carry, bt2);
			h->trees[i] = nullptr;
			break;//carry != nullptr, bt1 = nullptr, bt2 != nullptr
		case 7:
			carry = merge(carry, bt2);
			h->trees[i] = nullptr;
			break;//carry != nullptr, bt1 != nullptr, bt2 != nullptr
		default:
			break;
		}//switch

		if (!this->trees[i])
			continue;

		int Val = this->trees[i]->get_val();
		if (temp_min_pos < 0 || compare_func(Val, min_val)) {   //If the current heap is empty, or the val of the BinTree that needs to be merged is smaller than the smallest val in the current heap, update min_pos
			min_val = Val;
			temp_min_pos = i;
		}
	}//for

	min_pos = temp_min_pos;  //update min_pos
}
