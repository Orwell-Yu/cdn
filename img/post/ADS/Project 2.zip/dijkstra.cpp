#include <iostream>
#include <stdbool.h>
#include <stdlib.h>
#include <cstring>
#include <fstream>
#include <limits.h>
#include <cstring>
#include "Queue.h"
#include "BHeap.h"
#include "FHeap.h"


#define DIRECTED  1  //used to have to consider whether, if the undirected graph, comment out the define it


#define E_SIZE 150000000   //Max Edges
#define V_SIZE 30000000    //Max Nodes

using namespace std;


class Edge
{
public:
	Edge(int t, int l, int n) :to(t), length(l), next(n) {};
	int to;//destination
	int length;  //length of the edge
	int next; //next edge
};

int* heads, * dis, *visited;
//heads[i] is the first edge of node i, dis[i] is the shortest distance from the starting point to node i, visited[i] is the flag of whether node i has been visited

Edge** edges;//Edge Array

//2500 6071 1760

void initialize()
{
	edges   = new Edge*[E_SIZE];
	heads   = new int[V_SIZE];
	dis     = new int[V_SIZE];
	visited = new int[V_SIZE];
	for (int i = 0; i < V_SIZE; i++)
		heads[i] = -1;

	int a, b, length;
	int count = 0;


// Input method: Each line contains 3 digits, which is a b length
// For a directed graph, a is the starting point and b is the ending point
// Enter -1 in the last line, indicating that data entry is complete
// Need to change to read file format
// The final output should also be changed to write file form
	ifstream fin;

	string templine;
	char str[64];


	char c;
	freopen("data.txt", "r", stdin);


//int Count = 15;
	while (1){
	cin >> c;
	if (c == 'c')
	break;
	cin >> a;
	cin >> b;
	cin >> length;
	//cout << "get:" << c << " " << a << " " << b << " " << length << endl;
	//get a ,b and length

	edges[count] = new Edge(b, length, heads[a]);
	heads[a] = count;
	count++;
	}
	cout << "There is " <<count << " lines in total." << endl;
	//freopen( "CON", "w", stdout ); 
}


bool comp_func(int val_1, int val_2)
{
	return dis[val_1] <= dis[val_2];
}


void show_result()
{
	ofstream fout;
	fout.open("result.txt");//open the data.txt file in the current directory
	// cout << "hello world" << endl;
	// if(!fout.is_open()){
	// 	cout << "File NOT Found!" << endl;
	// 	return;
	// }
	for (int i = 0; i < V_SIZE -1 ; i++)
		if(dis[i] != INT_MAX)
			fout << dis[i] << endl;
	fout.close();
}

void  Dijkstra_FHeap()
{
	//memset(dis,0x3F,sizeof(dis));
	//memset(visited, 0, sizeof(visited));
	
	for (int i = 0; i < V_SIZE; i++)
	{
		visited[i] = 0;
		dis[i] = INT_MAX;
	}

	Queue<FHeap> q(comp_func);//change the type of queue here

	//push  source
	int src = 1;
	//cout << "Please input the start point:" << endl;
	//cin >> src;
	q.push_ele(src);
	dis[src] = 0;
	while (!q.empty())
	{
		
		int from = q.pop();//Take the first element of the line

		if (visited[from])//If the node has been visited
			continue;

		visited[from] = true;
		for (int i = heads[from]; i >= 0; i = edges[i]->next)
		{
			int length = edges[i]->length;
			int to = edges[i]->to;

			if (dis[to] > dis[from] + length)
			{
				dis[to] = dis[from] + length;
				q.push_ele(to);
			}
		}
		//cout << "ok" << endl;
		//show_result();
	}
}

void  Dijkstra_BHeap()
{
	//memset(dis,0x3F,sizeof(dis));
	//memset(visited, 0, sizeof(visited));
	
	for (int i = 0; i < V_SIZE; i++)
	{
		visited[i] = 0;
		dis[i] = INT_MAX;
	}

	Queue<BHeap> q(comp_func);//change the type of queue here

	//push  source
	int src = 1;
	//cout << "Please input the start point:" << endl;
	//cin >> src;
	q.push_ele(src);
	dis[src] = 0;
	while (!q.empty())
	{
		
		int from = q.pop();//Take the first element of the line

		if (visited[from])//If the node has been visited
			continue;

		visited[from] = true;
		for (int i = heads[from]; i >= 0; i = edges[i]->next)
		{
			int length = edges[i]->length;
			int to = edges[i]->to;

			if (dis[to] > dis[from] + length)
			{
				dis[to] = dis[from] + length;
				q.push_ele(to);
			}
		}
		//cout << "ok" << endl;
		//show_result();
	}
}

/*
http://www.diag.uniroma1.it/challenge9/data/USA-road-d/USA-road-d.NY.gr.gz

*/