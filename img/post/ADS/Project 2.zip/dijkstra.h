#pragma once

void initialize();
void Dijkstra_FHeap();
void Dijkstra_BHeap();
void show_result();