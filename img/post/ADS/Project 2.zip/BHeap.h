#pragma once
#include "simple_comp.h"

class BinTree {
public:
	BinTree()
		:rightchild(nullptr), leftsibling(nullptr), val(0), compare_func(simple_comp) {};
	BinTree(int v)
		:rightchild(nullptr), leftsibling(nullptr), val(v), compare_func(simple_comp) {};
	BinTree(int v, bool (*compare_func)(int, int))
		:rightchild(nullptr), leftsibling(nullptr), val(v), compare_func(compare_func) {};

	int get_val() { return val; }
	BinTree* get_child() { return rightchild; }
	BinTree* get_sib() { return leftsibling; }
	void set_child(BinTree* rc) { rightchild = rc; }
	void set_sib(BinTree* ls) { leftsibling = ls; }

	//�Ƚ������������
	bool operator <= (BinTree n)
	{
		return compare_func(this->val, n.val);
	}
	bool operator > (BinTree n)
	{
		return !compare_func(this->val, n.val);
	}
	bool operator >= (BinTree n)
	{
		return compare_func(n.val, this->val);
	}
	bool operator < (BinTree n)
	{
		return !compare_func(n.val, this->val);
	}
private:
	int val;
	BinTree* rightchild;
	BinTree* leftsibling;
	bool (*compare_func)(int, int);
};

class BHeap {
public:
	BHeap()
		:cur_size(0), min_pos(-1), max_size(10), compare_func(simple_comp)
	{
		trees = new BinTree * [max_size];
		for (int i = 0; i < max_size; i++)
		{
			trees[i] = nullptr;
		}
	}
	BHeap(bool (*compare_func)(int, int))
		:cur_size(0), min_pos(-1), max_size(10), compare_func(compare_func)
	{
		trees = new BinTree * [max_size];
		for (int i = 0; i < max_size; i++)
		{
			trees[i] = nullptr;
		}
	}
	bool empty() { return cur_size == 0; };
	bool size() { return cur_size; };
	void Merge(BHeap* h);
	void push(int val);
	int DeleteMin();
	void trans_BT(BinTree* bt, int pos);   //��һ��BTת��ΪHeap
private:
	int max_size;
	int cur_size;
	int min_pos;
	bool (*compare_func)(int, int);
	BinTree** trees;
};
