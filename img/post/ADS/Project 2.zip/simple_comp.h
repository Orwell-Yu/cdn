#pragma once
#include <cstring>
static bool simple_comp(int val_1, int val_2)
{
	return val_1 <= val_2;
}