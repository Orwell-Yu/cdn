#include "dijkstra.h"
#include <sys/time.h>
#include <time.h>
#include <iostream>
using namespace std;

double start1, stop1,start2, stop2;
double duration1,duration2;

double get_time()
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec + t.tv_usec/1000000.0;
}//to set the timer

int main()
{
	initialize();

	start1 = get_time();
	Dijkstra_FHeap();
	stop1 = get_time();
	duration1 = stop1 - start1;
	cout << "The total runtime of FHeap is " << duration1 << " seconds." << endl;

	start2 = get_time();
	Dijkstra_BHeap();
	stop2 = get_time();
	duration2 = stop2 - start2;
	cout << "The total runtime of BHeap is " << duration2 << " seconds." << endl;

	show_result();
}